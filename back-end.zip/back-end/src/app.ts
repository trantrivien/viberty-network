import express, { Application } from "express";
import cors from "cors";
import { initDatabase } from "./config/database";
import { env } from "./config/env";
import routes from "./routes";
import { errorMiddleware } from "./middleware/errorMiddleware";
import { logger } from "./utils/logger";


const app: Application = express();

// Middleware
app.use(cors());
app.use(express.json());
app.use((req, res, next) => {
  logger.info(`${req.method} ${req.url}`);
  next();
});

// Swagger configuration
const swaggerOptions = {
  definition: {
    openapi: "3.1.0",
    info: {
      title: "VIberty API",
      version: "1.0.0",
      description:
        "API for VIberty app with features similar to Pi Network and Hamster Kombat",
      contact: {
        name: "VIberty Support",
        email: "support@viberty.com",
      },
    },
    servers: [
      {
        url: `http://localhost:${env.port}`,
        description: "Development server",
      },
    ],
  },
  apis: ["./src/routes/*.ts"], // Scan route files for JSDoc comments
};

// Routes
app.use("/api", routes);

// Error handling
app.use(errorMiddleware);

// Start server
const startServer = async () => {
  try {
    const pool = await initDatabase();
    app.set("dbPool", pool);
    app.listen(env.port, () => {
      logger.info(`Server running on port ${env.port}`);
    });
  } catch (error) {
    logger.error("Failed to start server:", error);
    process.exit(1);
  }
};

startServer();
