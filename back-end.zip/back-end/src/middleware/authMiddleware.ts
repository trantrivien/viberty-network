import { Request, Response, NextFunction } from 'express';
import jwt from 'jsonwebtoken';
import { env } from '../config/env';
import { ApiError } from '../utils/response';

export const authenticateToken = (req: any, res: Response, next: NextFunction) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (!token) {
    throw new ApiError(401, 'Access denied');
  }

  jwt.verify(token, env.jwtSecret, (err:any, user:any) => {
    if (err) {
      throw new ApiError(403, 'Invalid token');
    }
    req.user = user as { userId: number };
    next();
  });
};