import { Router } from 'express';
import authRoutes from './authRoutes';
import miningRoutes from './miningRoutes';
import itemRoutes from './itemRoutes';
import taskRoutes from './taskRoutes';
import notificationRoutes from './notificationRoutes';

const router = Router();

router.use('/auth', authRoutes);
router.use('/mining', miningRoutes);
router.use('/items', itemRoutes);
router.use('/tasks', taskRoutes);
router.use('/notifications', notificationRoutes);

export default router;