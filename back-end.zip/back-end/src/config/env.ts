
export const env = {
  port: process.env.PORT || '3036',
  database: {
    host: process.env.DATABASE_HOST || '194.233.74.186',
    user: process.env.DATABASE_USER || 'root',
    password: process.env.DATABASE_PASSWORD || 'djbetranprod98',
    name: process.env.DATABASE_NAME || 'viberty',
  },
  jwtSecret: process.env.JWT_SECRET || 'secret',
};